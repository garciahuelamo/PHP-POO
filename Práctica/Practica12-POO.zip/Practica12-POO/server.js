var servidor = require('http'); 
var archivos = require('fs'); 
var ruta = require('url');
var procesador = require('querystring');
var mysql = require('mysql');
//npm install mysql

servidor.createServer(function(req, res){ 
    
    res.writeHead(200, {'Content-Type': 'text/html'}) 

    var rutacompleta = ruta.parse(req.url, true);
    archivos.readFile('Templates/header.html', function(err, data){
        var conexion = mysql.createConnection({
            host:"localhost",
            user:"angiebenzo",
            password:"angiebenzo",
            database:"avp_enterprise"
        })        
        res.write(data);
        switch(req.url){
            case "/":
                archivos.readFile('index.html', function(err, data){
                    res.write(data);
                });
                break;
            case "/clients":
                conexion.connect(function(err){
                    if(err) throw err;
                    console.log("conectado");
                    conexion.query(`
                        SELECT * FROM clientes
                    `, function(err, result, fields){
                        if(err) throw err;
                        console.log(result);
                        for(let i=0;i<result.length;i++){
                            console.log(result[i]);
                        }
                    });
                })
                break;  
            case "/trailers":  
                conexion.connect(function(err){
                    if(err) throw err;
                    console.log("conectado");
                    conexion.query(`
                        SELECT * FROM remolques
                    `, function(err, result, fields){
                        if(err) throw err;
                        console.log(result);
                        for(let i=0;i<result.length;i++){
                            console.log(result[i]);
                        }
                    });
                })
                break;
            case "/procesa":
                let datos = "";
                req.on('data', parte => {
                    datos += parte.toString();
                })
                req.on('end', ()=>{
                    var cadena = datos;
                    var procesado = procesador.parse(cadena);
                    console.log(procesado);
                })
                break; 
            default:
                res.end("Página no encontrada");
        }
    
        archivos.readFile('Templates/footer.html', function(err, data){
            res.write(data);
                res.end("");
        });
    });

    if(req.url != "favicon.ico"){
        var fecha = new Date();
        archivos.appendFile("registro.txt", fecha.getFullYear() + "," + fecha.getMonth() + "," + fecha.getDate + "," + rutacompleta.host + "," + rutacompleta.pathname + "," + rutacompleta.search + "," + req.url+"\n", function(err){
            if(err) throw err;
        })
    }

}).listen(8080)  

