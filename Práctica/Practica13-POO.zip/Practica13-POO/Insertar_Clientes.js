db.clientes.insertMany([
    {
        nombre: "Aluminium SL",
        cif: "A12345678B",
        direccion: "Calle Ficticia 123",
        cp: "28001",
        horario: "8-16, 17-20h",
        telefono: "639934765"
    },
    {
        nombre: "Aluminium SL 2",
        cif: "A12345678C",
        direccion: "Calle Ficticia 12",
        cp: "2800",
        horario: "8-16, 17-20h",
        telefono: "639934764"
    },
    {
        nombre: "Aluminium SL 3",
        cif: "A12345678D",
        direccion: "Calle Ficticia 13",
        cp: "28002",
        horario: "8-16, 17-20h",
        telefono: "639934763"
    },
    {
        nombre: "Aluminium SL 4",
        cif: "A12345678E",
        direccion: "Calle Ficticia 14",
        cp: "28003",
        horario: "8-16, 17-20h",
        telefono: "639934762"
    }
])