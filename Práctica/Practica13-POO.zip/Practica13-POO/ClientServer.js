var mongoose = require('mongoose');
//npm install mongoose

const Conexion = 'mongodb://127.0.0.1/avp_enterprise';

//Recuperación de elementos de la BD:

const ClientesEsquema = new mongoose.Schema({
    nombre:String,
    cif:String,
    direccion:String,
    cp:String,
    horario:String,
    telefono:String
})

const Formulario = mongoose.model("Clientes", ClientesEsquema);

//Listado de elementos:

mongoose.connect(Conexion, {useNewUrlParser:true, useUnifiedTopology:true}).then(function(){
    console.log("Conectado a mongo");
    Formulario.find({})
        .exec() //Ejecuta la accion
        .then(function(avp_enterprise){
            console.log(avp_enterprise);
        })
})

//Insertar elementos:

const NuevoCliente = new Formulario({
    nombre: "Aluminium SL 5",
    cif: "A12345678B",
    direccion: "Calle Ficticia 126",
    cp: "28001",
    horario: "8-16, 17-20h",
    telefono: "639934765"
})

mongoose.connect(Conexion, {useNewUrlParser:true, useUnifiedTopology:true}).then(function(){
    console.log("Conectado a mongo");
    NuevoCliente.save()
        .then(function(){
            console.log("Insertado");
        })
})

