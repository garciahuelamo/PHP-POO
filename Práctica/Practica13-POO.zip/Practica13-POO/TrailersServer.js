var mongoose = require('mongoose');
//npm install mongoose

const Conexion = 'mongodb://127.0.0.1/avp_enterprise';

//Recuperación de elementos de la BD:

const TrailersEsquema = new mongoose.Schema({
    matriculaRemolque:String,
    tipo:String,
    fechaMatriculacion:String,
    ITV:String
})

const Formulario = mongoose.model("Remolques", TrailersEsquema);

//Listado de elementos:

mongoose.connect(Conexion, {useNewUrlParser:true, useUnifiedTopology:true}).then(function(){
    console.log("Conectado a mongo");
    Formulario.find({})
        .exec() //Ejecuta la accion
        .then(function(avp_enterprise){
            console.log(avp_enterprise);
        })
})

//Insertar elementos:

const NuevoCliente = new Formulario({
    matriculaRemolque:"HROA1515",
    tipo:"MEGA",
    fechaMatriculacion:"2024-01-12",
    ITV:"2026-03-11"
})

mongoose.connect(Conexion, {useNewUrlParser:true, useUnifiedTopology:true}).then(function(){
    console.log("Conectado a mongo");
    NuevoCliente.save()
        .then(function(){
            console.log("Insertado");
        })
})
